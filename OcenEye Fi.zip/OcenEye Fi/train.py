import os
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import matplotlib.pyplot as plt
from model import MarineFoulingClassifier
import argparse

def create_sample_dataset_structure():
    """Create directory structure for sample dataset"""
    base_dir = 'data'
    train_dir = os.path.join(base_dir, 'train')
    val_dir = os.path.join(base_dir, 'validation')
    
    classes = ['clean', 'algae', 'barnacles', 'mixed']
    
    # Create directories
    for directory in [train_dir, val_dir]:
        for class_name in classes:
            class_dir = os.path.join(directory, class_name)
            os.makedirs(class_dir, exist_ok=True)
    
    print("✅ Dataset directory structure created")
    print(f"Training data: {train_dir}")
    print(f"Validation data: {val_dir}")
    
    return train_dir, val_dir

def generate_synthetic_images():
    """
    Generate synthetic marine fouling images for demonstration
    This creates realistic-looking images for each class
    """
    import cv2
    from PIL import Image, ImageDraw, ImageFilter
    import random
    
    def create_clean_hull_image(size=(224, 224)):
        """Create clean hull surface image"""
        # Create metallic/painted hull surface
        img = np.random.normal(120, 10, (*size, 3)).astype(np.uint8)
        img = np.clip(img, 80, 160)  # Keep in gray-blue range
        
        # Add some texture
        noise = np.random.normal(0, 5, (*size, 3))
        img = np.clip(img + noise, 0, 255).astype(np.uint8)
        
        return img
    
    def create_algae_image(size=(224, 224)):
        """Create image with algae growth"""
        # Start with hull base
        img = create_clean_hull_image(size)
        
        # Add green algae patches
        for _ in range(random.randint(5, 15)):
            center_x = random.randint(20, size[0]-20)
            center_y = random.randint(20, size[1]-20)
            radius = random.randint(10, 30)
            
            # Create circular algae patch
            y, x = np.ogrid[:size[0], :size[1]]
            mask = (x - center_x)**2 + (y - center_y)**2 <= radius**2
            
            # Green color with variation
            green_intensity = random.randint(40, 120)
            img[mask] = [random.randint(10, 30), green_intensity, random.randint(10, 40)]
        
        return img
    
    def create_barnacle_image(size=(224, 224)):
        """Create image with barnacle infestation"""
        # Start with hull base
        img = create_clean_hull_image(size)
        
        # Add barnacle clusters
        for _ in range(random.randint(10, 25)):
            center_x = random.randint(10, size[0]-10)
            center_y = random.randint(10, size[1]-10)
            
            # Create small white/gray circular barnacles
            for _ in range(random.randint(2, 6)):
                x = center_x + random.randint(-15, 15)
                y = center_y + random.randint(-15, 15)
                if 0 <= x < size[0] and 0 <= y < size[1]:
                    radius = random.randint(3, 8)
                    y_coords, x_coords = np.ogrid[:size[0], :size[1]]
                    mask = (x_coords - x)**2 + (y_coords - y)**2 <= radius**2
                    
                    # Barnacle color (whitish/grayish)
                    color = [random.randint(180, 220), 
                            random.randint(180, 210), 
                            random.randint(170, 200)]
                    img[mask] = color
        
        return img
    
    def create_mixed_fouling_image(size=(224, 224)):
        """Create image with mixed fouling"""
        # Start with hull base
        img = create_clean_hull_image(size)
        
        # Add algae (less dense)
        for _ in range(random.randint(3, 8)):
            center_x = random.randint(20, size[0]-20)
            center_y = random.randint(20, size[1]-20)
            radius = random.randint(8, 20)
            
            y, x = np.ogrid[:size[0], :size[1]]
            mask = (x - center_x)**2 + (y - center_y)**2 <= radius**2
            green_intensity = random.randint(30, 80)
            img[mask] = [random.randint(10, 20), green_intensity, random.randint(10, 30)]
        
        # Add barnacles
        for _ in range(random.randint(5, 15)):
            center_x = random.randint(10, size[0]-10)
            center_y = random.randint(10, size[1]-10)
            
            for _ in range(random.randint(1, 3)):
                x = center_x + random.randint(-10, 10)
                y = center_y + random.randint(-10, 10)
                if 0 <= x < size[0] and 0 <= y < size[1]:
                    radius = random.randint(2, 6)
                    y_coords, x_coords = np.ogrid[:size[0], :size[1]]
                    mask = (x_coords - x)**2 + (y_coords - y)**2 <= radius**2
                    
                    color = [random.randint(160, 200), 
                            random.randint(160, 190), 
                            random.randint(150, 180)]
                    img[mask] = color
        
        # Add some rust/corrosion
        for _ in range(random.randint(2, 5)):
            center_x = random.randint(30, size[0]-30)
            center_y = random.randint(30, size[1]-30)
            radius = random.randint(15, 25)
            
            y, x = np.ogrid[:size[0], :size[1]]
            mask = (x - center_x)**2 + (y - center_y)**2 <= radius**2
            img[mask] = [random.randint(80, 120), 
                        random.randint(40, 80), 
                        random.randint(20, 50)]
        
        return img
    
    # Generate images for each class
    generators = {
        'clean': create_clean_hull_image,
        'algae': create_algae_image,
        'barnacles': create_barnacle_image,
        'mixed': create_mixed_fouling_image
    }
    
    train_dir, val_dir = create_sample_dataset_structure()
    
    # Generate training images
    print("🔄 Generating synthetic training images...")
    for class_name, generator_func in generators.items():
        train_class_dir = os.path.join(train_dir, class_name)
        val_class_dir = os.path.join(val_dir, class_name)
        
        # Generate training images (more)
        for i in range(50):  # 50 images per class for training
            img = generator_func()
            img_path = os.path.join(train_class_dir, f'{class_name}_{i:03d}.jpg')
            cv2.imwrite(img_path, img)
        
        # Generate validation images (fewer)
        for i in range(15):  # 15 images per class for validation
            img = generator_func()
            img_path = os.path.join(val_class_dir, f'{class_name}_val_{i:03d}.jpg')
            cv2.imwrite(img_path, img)
        
        print(f"  ✅ Generated images for class: {class_name}")
    
    print("✅ Synthetic dataset generation completed!")
    return train_dir, val_dir

def train_marine_fouling_model():
    """Train the marine fouling classification model"""
    
    print("🚀 Starting MarineGuard Model Training...")
    
    # Generate synthetic dataset
    train_dir, val_dir = generate_synthetic_images()
    
    # Initialize classifier
    classifier = MarineFoulingClassifier(model_type='resnet50')
    
    # Build model
    print("🏗️ Building model architecture...")
    model = classifier.build_model()
    print(f"✅ Model built with {model.count_params():,} parameters")
    
    # Create data generators
    print("📊 Creating data generators...")
    train_gen, val_gen = classifier.create_data_generators(
        train_dir=train_dir,
        validation_dir=val_dir,
        batch_size=16
    )
    
    print(f"Training samples: {train_gen.samples}")
    print(f"Validation samples: {val_gen.samples}")
    
    # Train model
    print("🎓 Training model...")
    history = classifier.train_model(
        train_generator=train_gen,
        validation_generator=val_gen,
        epochs=10  # Reduced for demo
    )
    
    # Save model
    print("💾 Saving trained model...")
    model_path = 'model/marine_fouling_model.h5'
    classifier.save_model(model_path)
    
    # Plot training history
    plot_training_history(history)
    
    print("✅ Training completed successfully!")
    print(f"📁 Model saved to: {model_path}")
    
    return classifier, history

def plot_training_history(history):
    """Plot training history"""
    import matplotlib.pyplot as plt
    
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    
    # Species accuracy
    axes[0, 0].plot(history.history['species_accuracy'], label='Training')
    axes[0, 0].plot(history.history['val_species_accuracy'], label='Validation')
    axes[0, 0].set_title('Species Classification Accuracy')
    axes[0, 0].set_xlabel('Epoch')
    axes[0, 0].set_ylabel('Accuracy')
    axes[0, 0].legend()
    axes[0, 0].grid(True)
    
    # Density accuracy
    axes[0, 1].plot(history.history['density_accuracy'], label='Training')
    axes[0, 1].plot(history.history['val_density_accuracy'], label='Validation')
    axes[0, 1].set_title('Density Classification Accuracy')
    axes[0, 1].set_xlabel('Epoch')
    axes[0, 1].set_ylabel('Accuracy')
    axes[0, 1].legend()
    axes[0, 1].grid(True)
    
    # Species loss
    axes[1, 0].plot(history.history['species_loss'], label='Training')
    axes[1, 0].plot(history.history['val_species_loss'], label='Validation')
    axes[1, 0].set_title('Species Classification Loss')
    axes[1, 0].set_xlabel('Epoch')
    axes[1, 0].set_ylabel('Loss')
    axes[1, 0].legend()
    axes[1, 0].grid(True)
    
    # Overall loss
    axes[1, 1].plot(history.history['loss'], label='Training')
    axes[1, 1].plot(history.history['val_loss'], label='Validation')
    axes[1, 1].set_title('Overall Loss')
    axes[1, 1].set_xlabel('Epoch')
    axes[1, 1].set_ylabel('Loss')
    axes[1, 1].legend()
    axes[1, 1].grid(True)
    
    plt.tight_layout()
    plt.savefig('model/training_history.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("📊 Training history plot saved to model/training_history.png")

def create_sample_images_for_demo():
    """Create sample images for demo purposes"""
    sample_dir = 'sample_images'
    os.makedirs(sample_dir, exist_ok=True)
    
    import cv2
    
    # Generate sample images with descriptive names
    samples = [
        ('clean_hull_surface.jpg', 'clean'),
        ('algae_growth_moderate.jpg', 'algae'),
        ('barnacle_infestation_heavy.jpg', 'barnacles'),
        ('mixed_fouling_severe.jpg', 'mixed'),
        ('hull_with_light_algae.jpg', 'algae'),
        ('clean_painted_surface.jpg', 'clean')
    ]
    
    def create_clean_hull_image(size=(224, 224)):
        """Create clean hull surface image"""
        # Create metallic/painted hull surface
        img = np.random.normal(120, 10, (*size, 3)).astype(np.uint8)
        img = np.clip(img, 80, 160)  # Keep in gray-blue range
        
        # Add some texture
        noise = np.random.normal(0, 5, (*size, 3))
        img = np.clip(img + noise, 0, 255).astype(np.uint8)
        
        return img
    
    def create_algae_image(size=(224, 224)):
        """Create image with algae growth"""
        # Start with hull base
        img = create_clean_hull_image(size)
        
        # Add green algae patches
        for _ in range(np.random.randint(5, 15)):
            center_x = np.random.randint(20, size[0]-20)
            center_y = np.random.randint(20, size[1]-20)
            radius = np.random.randint(10, 30)
            
            # Create circular algae patch
            y, x = np.ogrid[:size[0], :size[1]]
            mask = (x - center_x)**2 + (y - center_y)**2 <= radius**2
            
            # Green color with variation
            green_intensity = np.random.randint(40, 120)
            img[mask] = [np.random.randint(10, 30), green_intensity, np.random.randint(10, 40)]
        
        return img
    
    def create_barnacle_image(size=(224, 224)):
        """Create image with barnacle infestation"""
        # Start with hull base
        img = create_clean_hull_image(size)
        
        # Add barnacle clusters
        for _ in range(np.random.randint(10, 25)):
            center_x = np.random.randint(10, size[0]-10)
            center_y = np.random.randint(10, size[1]-10)
            
            # Create small white/gray circular barnacles
            for _ in range(np.random.randint(2, 6)):
                x = center_x + np.random.randint(-15, 15)
                y = center_y + np.random.randint(-15, 15)
                if 0 <= x < size[0] and 0 <= y < size[1]:
                    radius = np.random.randint(3, 8)
                    y_coords, x_coords = np.ogrid[:size[0], :size[1]]
                    mask = (x_coords - x)**2 + (y_coords - y)**2 <= radius**2
                    
                    # Barnacle color (whitish/grayish)
                    color = [np.random.randint(180, 220), 
                            np.random.randint(180, 210), 
                            np.random.randint(170, 200)]
                    img[mask] = color
        
        return img
    
    def create_mixed_fouling_image(size=(224, 224)):
        """Create image with mixed fouling"""
        # Start with hull base
        img = create_clean_hull_image(size)
        
        # Add algae (less dense)
        for _ in range(np.random.randint(3, 8)):
            center_x = np.random.randint(20, size[0]-20)
            center_y = np.random.randint(20, size[1]-20)
            radius = np.random.randint(8, 20)
            
            y, x = np.ogrid[:size[0], :size[1]]
            mask = (x - center_x)**2 + (y - center_y)**2 <= radius**2
            green_intensity = np.random.randint(30, 80)
            img[mask] = [np.random.randint(10, 20), green_intensity, np.random.randint(10, 30)]
        
        # Add barnacles
        for _ in range(np.random.randint(5, 15)):
            center_x = np.random.randint(10, size[0]-10)
            center_y = np.random.randint(10, size[1]-10)
            
            for _ in range(np.random.randint(1, 3)):
                x = center_x + np.random.randint(-10, 10)
                y = center_y + np.random.randint(-10, 10)
                if 0 <= x < size[0] and 0 <= y < size[1]:
                    radius = np.random.randint(2, 6)
                    y_coords, x_coords = np.ogrid[:size[0], :size[1]]
                    mask = (x_coords - x)**2 + (y_coords - y)**2 <= radius**2
                    
                    color = [np.random.randint(160, 200), 
                            np.random.randint(160, 190), 
                            np.random.randint(150, 180)]
                    img[mask] = color
        
        # Add some rust/corrosion
        for _ in range(np.random.randint(2, 5)):
            center_x = np.random.randint(30, size[0]-30)
            center_y = np.random.randint(30, size[1]-30)
            radius = np.random.randint(15, 25)
            
            y, x = np.ogrid[:size[0], :size[1]]
            mask = (x - center_x)**2 + (y - center_y)**2 <= radius**2
            img[mask] = [np.random.randint(80, 120), 
                        np.random.randint(40, 80), 
                        np.random.randint(20, 50)]
        
        return img
    
    generators = {
        'clean': lambda: create_clean_hull_image(),
        'algae': lambda: create_algae_image(),
        'barnacles': lambda: create_barnacle_image(),
        'mixed': lambda: create_mixed_fouling_image()
    }
    
    for filename, fouling_type in samples:
        img = generators[fouling_type]()
        filepath = os.path.join(sample_dir, filename)
        cv2.imwrite(filepath, img)
    
    print(f"✅ Sample demo images created in {sample_dir}/")

def main():
    """Main training function"""
    parser = argparse.ArgumentParser(description='Train MarineGuard fouling detection model')
    parser.add_argument('--generate-data', action='store_true', 
                       help='Generate synthetic dataset')
    parser.add_argument('--train', action='store_true', 
                       help='Train the model')
    parser.add_argument('--demo-images', action='store_true',
                       help='Create sample images for demo')
    parser.add_argument('--all', action='store_true',
                       help='Run all steps (generate data, train, create demo images)')
    
    args = parser.parse_args()
    
    if args.all or (not any([args.generate_data, args.train, args.demo_images])):
        # Run all steps if no specific step is chosen
        print("🌊 Running complete MarineGuard training pipeline...")
        
        # Generate synthetic dataset
        generate_synthetic_images()
        
        # Train model
        train_marine_fouling_model()
        
        # Create demo images
        create_sample_images_for_demo()
        
        print("\n🎉 MarineGuard training pipeline completed successfully!")
        print("📁 Files created:")
        print("  - model/marine_fouling_model.h5 (trained model)")
        print("  - model/training_history.png (training plots)")
        print("  - data/ (synthetic dataset)")
        print("  - sample_images/ (demo images)")
        
    else:
        if args.generate_data:
            generate_synthetic_images()
        
        if args.train:
            train_marine_fouling_model()
        
        if args.demo_images:
            create_sample_images_for_demo()

if __name__ == "__main__":
    main()