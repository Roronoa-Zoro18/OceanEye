import cv2
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.image import img_to_array, load_img
from PIL import Image
import os

class ImagePreprocessor:
    """Handles image preprocessing for marine fouling detection"""
    
    def __init__(self, target_size=(224, 224)):
        self.target_size = target_size
    
    def preprocess_image(self, image_path):
        """
        Preprocess image for model prediction
        
        Args:
            image_path: Path to the input image
            
        Returns:
            Preprocessed image array ready for model
        """
        # Load and resize image
        img = load_img(image_path, target_size=self.target_size)
        img_array = img_to_array(img)
        img_array = np.expand_dims(img_array, axis=0)
        img_array = img_array / 255.0  # Normalize to [0,1]
        
        return img_array
    
    def load_and_preprocess_batch(self, image_paths):
        """Load and preprocess multiple images"""
        batch = []
        for path in image_paths:
            img_array = self.preprocess_image(path)
            batch.append(img_array[0])  # Remove batch dimension
        return np.array(batch)

class FoulingDensityEstimator:
    """Estimates fouling density using OpenCV image processing"""
    
    def __init__(self):
        self.density_thresholds = {
            'low': (0, 30),
            'medium': (30, 60),
            'high': (60, 100)
        }
    
    def estimate_fouling_coverage(self, image_path):
        """
        Estimate the percentage of fouling coverage
        
        Args:
            image_path: Path to the input image
            
        Returns:
            Dictionary with coverage percentage and density level
        """
        # Load image
        img = cv2.imread(image_path)
        if img is None:
            return {'coverage_percent': 0, 'density_level': 'clean', 'processed_image': None}
        
        # Convert to different color spaces for better detection
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        # Create masks for different fouling types
        fouling_mask = self._create_fouling_mask(hsv, gray)
        
        # Calculate coverage percentage
        total_pixels = img.shape[0] * img.shape[1]
        fouling_pixels = np.sum(fouling_mask > 0)
        coverage_percent = (fouling_pixels / total_pixels) * 100
        
        # Determine density level
        density_level = self._get_density_level(coverage_percent)
        
        # Create visualization
        processed_img = self._create_visualization(img, fouling_mask)
        
        return {
            'coverage_percent': round(coverage_percent, 2),
            'density_level': density_level,
            'processed_image': processed_img
        }
    
    def _create_fouling_mask(self, hsv, gray):
        """Create mask to detect fouling areas"""
        # Detect green/brown areas (algae)
        lower_green = np.array([35, 40, 40])
        upper_green = np.array([85, 255, 255])
        green_mask = cv2.inRange(hsv, lower_green, upper_green)
        
        # Detect brown areas (rust/corrosion)
        lower_brown = np.array([10, 50, 20])
        upper_brown = np.array([20, 255, 200])
        brown_mask = cv2.inRange(hsv, lower_brown, upper_brown)
        
        # Detect dark areas (heavy fouling)
        dark_mask = cv2.threshold(gray, 60, 255, cv2.THRESH_BINARY_INV)[1]
        
        # Combine masks
        combined_mask = cv2.bitwise_or(green_mask, brown_mask)
        combined_mask = cv2.bitwise_or(combined_mask, dark_mask)
        
        # Apply morphological operations to clean up the mask
        kernel = np.ones((5, 5), np.uint8)
        combined_mask = cv2.morphologyEx(combined_mask, cv2.MORPH_CLOSE, kernel)
        combined_mask = cv2.morphologyEx(combined_mask, cv2.MORPH_OPEN, kernel)
        
        return combined_mask
    
    def _get_density_level(self, coverage_percent):
        """Determine density level based on coverage percentage"""
        if coverage_percent <= self.density_thresholds['low'][1]:
            return 'low'
        elif coverage_percent <= self.density_thresholds['medium'][1]:
            return 'medium'
        else:
            return 'high'
    
    def _create_visualization(self, original_img, mask):
        """Create visualization showing fouling areas"""
        # Create colored overlay for fouling areas
        overlay = original_img.copy()
        overlay[mask > 0] = [0, 0, 255]  # Red for fouling areas
        
        # Blend with original image
        result = cv2.addWeighted(original_img, 0.7, overlay, 0.3, 0)
        
        return result

def get_risk_level_info(density_level, coverage_percent):
    """
    Get risk level information and maintenance recommendations
    
    Args:
        density_level: 'low', 'medium', or 'high'
        coverage_percent: Percentage of fouling coverage
        
    Returns:
        Dictionary with risk info and recommendations
    """
    risk_info = {
        'low': {
            'color': '#28a745',  # Green
            'risk_level': 'LOW RISK',
            'maintenance': 'Routine inspection recommended',
            'urgency': 'Schedule cleaning within 3-6 months',
            'impact': 'Minimal impact on performance'
        },
        'medium': {
            'color': '#ffc107',  # Yellow
            'risk_level': 'MEDIUM RISK', 
            'maintenance': 'Cleaning recommended soon',
            'urgency': 'Schedule cleaning within 1-2 months',
            'impact': 'Moderate impact on fuel efficiency'
        },
        'high': {
            'color': '#dc3545',  # Red
            'risk_level': 'HIGH RISK',
            'maintenance': 'IMMEDIATE cleaning required',
            'urgency': 'Schedule cleaning within 2 weeks',
            'impact': 'Significant performance degradation'
        }
    }
    
    return risk_info.get(density_level, risk_info['low'])

def create_sample_data():
    """Create sample data for demonstration"""
    sample_data = {
        'Clean Hull': {
            'species': 'Clean',
            'density': 'low',
            'coverage': 5.2,
            'description': 'Hull surface is clean with minimal marine growth'
        },
        'Algae Growth': {
            'species': 'Algae',
            'density': 'medium',
            'coverage': 45.8,
            'description': 'Moderate algae growth detected on hull surface'
        },
        'Barnacle Infestation': {
            'species': 'Barnacles',
            'density': 'high',
            'coverage': 78.3,
            'description': 'Heavy barnacle infestation requiring immediate attention'
        },
        'Mixed Fouling': {
            'species': 'Mixed',
            'density': 'high',
            'coverage': 65.7,
            'description': 'Multiple fouling species detected with high coverage'
        }
    }
    return sample_data