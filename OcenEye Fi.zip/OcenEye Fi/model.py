import tensorflow as tf
from tensorflow.keras.applications import ResNet50, MobileNetV2
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D, Dropout
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import numpy as np
import os
import pickle

class MarineFoulingClassifier:
    """
    Deep Learning model for marine fouling detection and classification
    Uses transfer learning with ResNet50 or MobileNetV2
    """
    
    def __init__(self, model_type='resnet50', num_classes=4, input_shape=(224, 224, 3)):
        """
        Initialize the classifier
        
        Args:
            model_type: 'resnet50' or 'mobilenet'
            num_classes: Number of fouling classes (Clean, Algae, Barnacles, Mixed)
            input_shape: Input image shape
        """
        self.model_type = model_type
        self.num_classes = num_classes
        self.input_shape = input_shape
        self.model = None
        self.class_names = ['Clean', 'Algae', 'Barnacles', 'Mixed']
        
    def build_model(self):
        """Build the transfer learning model"""
        # Load pre-trained base model
        if self.model_type == 'resnet50':
            base_model = ResNet50(
                weights='imagenet',
                include_top=False,
                input_shape=self.input_shape
            )
        else:  # mobilenet
            base_model = MobileNetV2(
                weights='imagenet',
                include_top=False,
                input_shape=self.input_shape
            )
        
        # Freeze base model layers
        base_model.trainable = False
        
        # Add custom classification head
        x = base_model.output
        x = GlobalAveragePooling2D()(x)
        x = Dense(512, activation='relu')(x)
        x = Dropout(0.5)(x)
        x = Dense(256, activation='relu')(x)
        x = Dropout(0.3)(x)
        
        # Output layers for multi-task learning
        species_output = Dense(self.num_classes, activation='softmax', name='species')(x)
        density_output = Dense(3, activation='softmax', name='density')(x)  # low, medium, high
        
        # Create model
        self.model = Model(
            inputs=base_model.input,
            outputs=[species_output, density_output]
        )
        
        # Compile model
        self.model.compile(
            optimizer=Adam(learning_rate=0.001),
            loss={
                'species': 'categorical_crossentropy',
                'density': 'categorical_crossentropy'
            },
            loss_weights={'species': 1.0, 'density': 0.5},
            metrics=['accuracy']
        )
        
        return self.model
    
    def create_data_generators(self, train_dir, validation_dir=None, batch_size=32):
        """Create data generators for training"""
        # Data augmentation for training
        train_datagen = ImageDataGenerator(
            rescale=1./255,
            rotation_range=20,
            width_shift_range=0.2,
            height_shift_range=0.2,
            horizontal_flip=True,
            zoom_range=0.2,
            shear_range=0.1,
            brightness_range=[0.8, 1.2],
            validation_split=0.2 if validation_dir is None else 0.0
        )
        
        # Validation data generator (no augmentation)
        val_datagen = ImageDataGenerator(rescale=1./255)
        
        # Create generators
        if validation_dir is None:
            # Use split from training data
            train_generator = train_datagen.flow_from_directory(
                train_dir,
                target_size=self.input_shape[:2],
                batch_size=batch_size,
                class_mode='categorical',
                subset='training'
            )
            
            validation_generator = train_datagen.flow_from_directory(
                train_dir,
                target_size=self.input_shape[:2],
                batch_size=batch_size,
                class_mode='categorical',
                subset='validation'
            )
        else:
            # Use separate validation directory
            train_generator = train_datagen.flow_from_directory(
                train_dir,
                target_size=self.input_shape[:2],
                batch_size=batch_size,
                class_mode='categorical'
            )
            
            validation_generator = val_datagen.flow_from_directory(
                validation_dir,
                target_size=self.input_shape[:2],
                batch_size=batch_size,
                class_mode='categorical'
            )
        
        return train_generator, validation_generator
    
    def train_model(self, train_generator, validation_generator, epochs=20):
        """Train the model"""
        if self.model is None:
            self.build_model()
        
        # Callbacks
        callbacks = [
            tf.keras.callbacks.EarlyStopping(
                monitor='val_loss',
                patience=5,
                restore_best_weights=True
            ),
            tf.keras.callbacks.ReduceLROnPlateau(
                monitor='val_loss',
                factor=0.2,
                patience=3,
                min_lr=1e-7
            ),
            tf.keras.callbacks.ModelCheckpoint(
                'model/best_marine_fouling_model.h5',
                monitor='val_loss',
                save_best_only=True,
                save_weights_only=False
            )
        ]
        
        # Train model
        history = self.model.fit(
            train_generator,
            epochs=epochs,
            validation_data=validation_generator,
            callbacks=callbacks
        )
        
        return history
    
    def predict(self, image_array):
        """
        Make prediction on preprocessed image
        
        Args:
            image_array: Preprocessed image array
            
        Returns:
            Dictionary with species and density predictions
        """
        if self.model is None:
            raise ValueError("Model not loaded. Please load a trained model first.")
        
        # Make prediction
        species_pred, density_pred = self.model.predict(image_array)
        
        # Get predicted classes
        species_idx = np.argmax(species_pred[0])
        density_idx = np.argmax(density_pred[0])
        
        species_confidence = float(species_pred[0][species_idx])
        density_confidence = float(density_pred[0][density_idx])
        
        density_labels = ['low', 'medium', 'high']
        
        return {
            'species': self.class_names[species_idx],
            'species_confidence': species_confidence,
            'density': density_labels[density_idx],
            'density_confidence': density_confidence,
            'species_probabilities': {
                self.class_names[i]: float(species_pred[0][i]) 
                for i in range(len(self.class_names))
            },
            'density_probabilities': {
                density_labels[i]: float(density_pred[0][i]) 
                for i in range(len(density_labels))
            }
        }
    
    def save_model(self, filepath):
        """Save the trained model"""
        if self.model is not None:
            self.model.save(filepath)
            # Save class names
            with open(filepath.replace('.h5', '_classes.pkl'), 'wb') as f:
                pickle.dump(self.class_names, f)
    
    def load_model(self, filepath):
        """Load a trained model"""
        self.model = tf.keras.models.load_model(filepath)
        # Load class names if available
        try:
            with open(filepath.replace('.h5', '_classes.pkl'), 'rb') as f:
                self.class_names = pickle.load(f)
        except FileNotFoundError:
            print("Class names file not found, using default class names")

def simulate_trained_model():
    """
    Create a simulated trained model for demo purposes
    This replaces actual training when no real dataset is available
    """
    classifier = MarineFoulingClassifier()
    classifier.build_model()
    
    # Create dummy training to initialize weights properly
    dummy_x = np.random.random((10, 224, 224, 3))
    dummy_y_species = tf.keras.utils.to_categorical(np.random.randint(0, 4, 10), 4)
    dummy_y_density = tf.keras.utils.to_categorical(np.random.randint(0, 3, 10), 3)
    
    # Compile and fit with dummy data
    classifier.model.fit(
        dummy_x, 
        [dummy_y_species, dummy_y_density], 
        epochs=1, 
        verbose=0
    )
    
    # Save the simulated model
    os.makedirs('model', exist_ok=True)
    classifier.save_model('model/marine_fouling_model.h5')
    
    return classifier

def create_sample_predictions(image_name):
    """
    Create realistic sample predictions for demo
    This simulates what a trained model would output
    """
    import random
    
    # Define realistic scenarios based on image name/type
    scenarios = {
        'clean': {
            'species': 'Clean',
            'species_confidence': random.uniform(0.85, 0.95),
            'density': 'low',
            'density_confidence': random.uniform(0.80, 0.90)
        },
        'algae': {
            'species': 'Algae',
            'species_confidence': random.uniform(0.75, 0.90),
            'density': random.choice(['medium', 'high']),
            'density_confidence': random.uniform(0.70, 0.85)
        },
        'barnacle': {
            'species': 'Barnacles',
            'species_confidence': random.uniform(0.80, 0.92),
            'density': random.choice(['medium', 'high']),
            'density_confidence': random.uniform(0.75, 0.88)
        },
        'mixed': {
            'species': 'Mixed',
            'species_confidence': random.uniform(0.70, 0.85),
            'density': 'high',
            'density_confidence': random.uniform(0.75, 0.85)
        }
    }
    
    # Determine scenario based on image name
    scenario = 'clean'  # default
    image_lower = image_name.lower()
    if 'algae' in image_lower or 'green' in image_lower:
        scenario = 'algae'
    elif 'barnacle' in image_lower or 'shell' in image_lower:
        scenario = 'barnacle'
    elif 'mixed' in image_lower or 'fouling' in image_lower:
        scenario = 'mixed'
    elif 'dirty' in image_lower or 'rust' in image_lower:
        scenario = random.choice(['algae', 'mixed'])
    
    base_pred = scenarios[scenario]
    
    # Create full prediction structure
    class_names = ['Clean', 'Algae', 'Barnacles', 'Mixed']
    density_labels = ['low', 'medium', 'high']
    
    # Generate probabilities that sum to 1
    species_probs = [0.1, 0.1, 0.1, 0.1]  # base probabilities
    species_idx = class_names.index(base_pred['species'])
    species_probs[species_idx] = base_pred['species_confidence']
    
    # Normalize remaining probabilities
    remaining_prob = 1.0 - base_pred['species_confidence']
    for i in range(len(species_probs)):
        if i != species_idx:
            species_probs[i] = remaining_prob / (len(species_probs) - 1)
    
    # Similar for density
    density_probs = [0.2, 0.2, 0.2]
    density_idx = density_labels.index(base_pred['density'])
    density_probs[density_idx] = base_pred['density_confidence']
    
    remaining_density_prob = 1.0 - base_pred['density_confidence']
    for i in range(len(density_probs)):
        if i != density_idx:
            density_probs[i] = remaining_density_prob / (len(density_probs) - 1)
    
    return {
        'species': base_pred['species'],
        'species_confidence': base_pred['species_confidence'],
        'density': base_pred['density'],
        'density_confidence': base_pred['density_confidence'],
        'species_probabilities': {
            class_names[i]: species_probs[i] for i in range(len(class_names))
        },
        'density_probabilities': {
            density_labels[i]: density_probs[i] for i in range(len(density_labels))
        }
    }