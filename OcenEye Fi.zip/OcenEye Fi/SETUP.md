# MarineGuard Setup Instructions

## Quick Setup (Recommended)

### 1. Install Python Dependencies
```bash
pip install -r requirements.txt
```

### 2. Run Complete Setup
```bash
# This will generate data, train model, and create demo images
python train.py --all
```

### 3. Launch Application
```bash
streamlit run app.py
```

### 4. Access Dashboard
Open `http://localhost:8501` in your browser.

## Manual Setup (Step by Step)

### Step 1: Generate Synthetic Dataset
```bash
python train.py --generate-data
```
This creates:
- `data/train/` with training images (50 per class)
- `data/validation/` with validation images (15 per class)

### Step 2: Train the AI Model
```bash
python train.py --train
```
This creates:
- `model/marine_fouling_model.h5` (trained model)
- `model/training_history.png` (training plots)

### Step 3: Create Demo Images
```bash
python train.py --demo-images
```
This creates:
- `sample_images/` with demo images for testing

### Step 4: Launch Application
```bash
streamlit run app.py
```

## Troubleshooting

### Common Issues

**TensorFlow Installation Issues (Windows)**
```bash
pip install tensorflow-cpu==2.13.0
```

**OpenCV Installation Issues**
```bash
pip install opencv-python-headless==4.8.1.78
```

**Streamlit Port Already in Use**
```bash
streamlit run app.py --server.port 8502
```

**Model Training Memory Issues**
Reduce batch size in train.py:
```python
batch_size=8  # Instead of 16
```

### System Requirements
- **Minimum**: 4GB RAM, Python 3.8+
- **Recommended**: 8GB RAM, Python 3.9+
- **GPU**: Optional, speeds up training significantly

## Demo Workflow

1. **Upload Image**: Use sample images or your own ship hull photos
2. **Analyze**: Click "Analyze Fouling" button
3. **Review Results**: Check species classification and density assessment
4. **View Statistics**: Monitor analysis history and trends
5. **Export Data**: Save results for reporting (future feature)

## Next Steps

- Try uploading different types of marine surface images
- Explore the statistics page to see analysis trends
- Check the About page for technical details
- Consider training with your own dataset for improved accuracy